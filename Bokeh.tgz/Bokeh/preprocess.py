import pandas as pd

FMT = "%m/%d/%Y %I:%M:%S %p"
input = "data_2024.csv"
output = "bokeh_app/monthly_zip.csv"

parts = []
for chunk in pd.read_csv(input, usecols=["Created Date", "Closed Date", "Incident Zip"],
                         dtype=str, chunksize=500_000):
    chunk = chunk.dropna(subset=["Closed Date", "Incident Zip"])          # not closed / no zip -> drop
    created = pd.to_datetime(chunk["Created Date"], format=FMT, errors="coerce")
    closed = pd.to_datetime(chunk["Closed Date"], format=FMT, errors="coerce")
    hours = (closed - created).dt.total_seconds() / 3600
    keep = (created.dt.year == 2024) & (hours >= 0)                       # opened in 2024, no negatives
    chunk = pd.DataFrame({"zip": chunk["Incident Zip"].str.strip()[keep],
                          "month": closed[keep].dt.to_period("M").astype(str),   # month it was CLOSED
                          "hours": hours[keep]})
    parts.append(chunk.groupby(["zip", "month"])["hours"].agg(total_hours="sum", n="count"))

out = pd.concat(parts).groupby(level=[0, 1]).sum().reset_index()
out.to_csv(output, index=False)
print(f"wrote {len(out)} rows to {output}")