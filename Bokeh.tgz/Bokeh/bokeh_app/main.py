from os.path import dirname, join

import pandas as pd
from bokeh.layouts import column
from bokeh.models import ColumnDataSource, Select
from bokeh.plotting import curdoc, figure

df = pd.read_csv(join(dirname(__file__), "monthly_zip.csv"), dtype={"zip": str})
months = sorted(df["month"].unique())
x = pd.to_datetime(months).to_pydatetime().tolist()

allm = df.groupby("month")[["total_hours", "n"]].sum().reindex(months)
all_avg = (allm["total_hours"] / allm["n"]).tolist()

by_zip = {z: g.set_index("month") for z, g in df.groupby("zip")}


def zip_avg(z):
    g = by_zip[z].reindex(months)
    return (g["total_hours"] / g["n"]).tolist()


zips = sorted(by_zip)
z1, z2 = zips[0], zips[min(1, len(zips) - 1)]


sel1 = Select(title="Zipcode 1", value=z1, options=zips)
sel2 = Select(title="Zipcode 2", value=z2, options=zips)

src = ColumnDataSource(data=dict(x=x, all=all_avg, z1=zip_avg(z1), z2=zip_avg(z2)))

fig = figure(x_axis_type="datetime", width=800, height=450,
             title="Monthly average 311 response time (create to closed)",
             x_axis_label="Month incident was closed", y_axis_label="Average response time (hours)")
fig.line("x", "all", source=src, line_width=2, color="gray", legend_label="All zipcodes")
fig.line("x", "z1", source=src, line_width=2, color="blue", legend_label=f"Zipcode {z1}")
fig.line("x", "z2", source=src, line_width=2, color="red", legend_label=f"Zipcode {z2}")
fig.legend.location = "top_left"
fig.legend.click_policy = "hide"


def update(attr, old, new):
    src.data = dict(x=x, all=all_avg, z1=zip_avg(sel1.value), z2=zip_avg(sel2.value))
    fig.legend.items[1].label = {"value": f"Zipcode {sel1.value}"}
    fig.legend.items[2].label = {"value": f"Zipcode {sel2.value}"}


sel1.on_change("value", update)
sel2.on_change("value", update)

curdoc().add_root(column(sel1, sel2, fig))
curdoc().title = "311 Response Time"